'use strict';

const { ActivityType } = require('discord.js');
const logger = require('../utils/logger');
const config = require('../../config.json');

const activities = [
  { name: '/play • PoolStreamer', type: ActivityType.Listening },
  { name: 'Music for everyone 🎵', type: ActivityType.Playing },
  { name: 'your requests • /help', type: ActivityType.Listening },
];

let activityIndex = 0;

module.exports = {
  name: 'ready',
  once: true,
  execute(client) {
    logger.info(`✅ Logged in as ${client.user.tag}`);
    logger.info(`📡 Serving ${client.guilds.cache.size} guild(s)`);
    logger.info(`🎵 PoolStreamer v${config.bot.version} is online`);

    // Restore 24/7 mode from DB on startup
    restoreTwentyFourSeven(client);

    // Rotating presence
    setActivity(client);
    setInterval(() => setActivity(client), 30_000);
  },
};

function setActivity(client) {
  const activity = activities[activityIndex % activities.length];
  client.user.setPresence({
    status: 'online',
    activities: [activity],
  });
  activityIndex++;
}

async function restoreTwentyFourSeven(client) {
  try {
    const GuildSettings = require('../database/models/GuildSettings');
    const docs = await GuildSettings.find({ twentyFourSeven: true });
    for (const doc of docs) {
      client.twentyFourSeven.set(doc.guildId, true);
    }
    if (docs.length > 0) {
      logger.info(`🌙 Restored 24/7 mode for ${docs.length} guild(s)`);
    }
  } catch (err) {
    logger.error(`Failed to restore 24/7 mode: ${err.message}`);
  }
}
