module.exports = {
  apps: [
    {
      name: 'poolstreamer',
      script: 'src/index.js',
      interpreter: 'node',
      watch: false,
      instances: 1,
      autorestart: true,
      max_memory_restart: '512M',
      restart_delay: 5000,
      max_restarts: 10,
      min_uptime: '10s',
      env: {
        NODE_ENV: 'production',
      },
      log_date_format: 'YYYY-MM-DD HH:mm:ss',
      error_file: 'logs/pm2-error.log',
      out_file: 'logs/pm2-out.log',
      merge_logs: true,
      kill_timeout: 10000,
    },
  ],
};
