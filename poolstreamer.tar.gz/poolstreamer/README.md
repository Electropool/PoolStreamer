# 🎵 PoolStreamer — Production Discord Music Bot

> A high-performance, feature-rich Discord music bot built with Node.js, discord.js v14, and Lavalink. Inspired by Hydrabot and FredBoat — ready for VPS deployment out of the box.

---

## 📋 Table of Contents

1. [Features](#-features)
2. [Commands](#-commands)
3. [Local Setup](#-local-setup)
4. [Lavalink Setup](#-lavalink-setup)
5. [VPS Deployment — PM2 + NGINX](#-vps-deployment--pm2--nginx)
6. [VPS Deployment — Cloudflare Tunnel](#-vps-deployment--cloudflare-tunnel)
7. [Security Hardening](#-security-hardening)
8. [Environment Variables](#-environment-variables)
9. [Project Structure](#-project-structure)
10. [Troubleshooting](#-troubleshooting)

---

## ✨ Features

| Feature | Status |
|---|---|
| YouTube / YouTube Music | ✅ |
| Spotify (metadata → YouTube) | ✅ |
| SoundCloud | ✅ |
| Direct search queries | ✅ |
| Interactive buttons + embeds | ✅ |
| Progress bar in now-playing | ✅ |
| Queue system (up to 500 tracks) | ✅ |
| Loop (track / queue / off) | ✅ |
| Shuffle | ✅ |
| Volume control (0–150%) | ✅ |
| Seek | ✅ |
| Autoplay | ✅ |
| 24/7 mode | ✅ |
| DJ role system | ✅ |
| Whitelist (channels + users) | ✅ |
| Blacklist (channels + users) | ✅ |
| MongoDB persistence | ✅ |
| Anti-spam protection | ✅ |
| Slash commands only | ✅ |
| Health check HTTP endpoint | ✅ |
| Winston logging (rotating files) | ✅ |
| PM2 process management | ✅ |

---

## 🎮 Commands

### Music Commands

| Command | Description |
|---|---|
| `/play <query>` | Play a song or playlist from YouTube, Spotify, SoundCloud or search |
| `/skip [amount]` | Skip current or next N tracks |
| `/pause` | Pause playback |
| `/resume` | Resume paused playback |
| `/stop` | Stop music and clear queue |
| `/leave` | Disconnect from voice channel |
| `/queue [page]` | Show the current queue |
| `/nowplaying` | Show current track with controls |
| `/loop <off\|track\|queue>` | Set loop mode |
| `/volume <0-150>` | Set volume |
| `/seek <position>` | Seek to position (e.g. `1:30` or `90`) |
| `/shuffle` | Shuffle the queue |
| `/247 <enable\|disable>` | Toggle 24/7 mode |
| `/autoplay <enable\|disable>` | Toggle autoplay |

### Admin Commands

| Command | Description |
|---|---|
| `/setdj add <role>` | Add a DJ role |
| `/setdj remove <role>` | Remove a DJ role |
| `/setdj list` | List all DJ roles |
| `/whitelist add-channel <ch>` | Whitelist a channel |
| `/whitelist remove-channel <ch>` | Remove channel from whitelist |
| `/whitelist add-user <user>` | Whitelist a user |
| `/whitelist remove-user <user>` | Remove user from whitelist |
| `/whitelist list` | Show whitelist |
| `/blacklist add-channel <ch>` | Blacklist a channel |
| `/blacklist remove-channel <ch>` | Remove channel from blacklist |
| `/blacklist add-user <user>` | Blacklist a user |
| `/blacklist remove-user <user>` | Remove user from blacklist |
| `/blacklist list` | Show blacklist |

---

## 🖥️ Local Setup

### Prerequisites

- **Node.js v20+** — [nodejs.org](https://nodejs.org)
- **Java 17+** — Required for Lavalink
- **MongoDB** — [mongodb.com](https://mongodb.com) (local or Atlas)

### Step 1 — Clone & Install

```bash
git clone https://github.com/yourname/poolstreamer.git
cd poolstreamer
npm install
```

### Step 2 — Configure Environment

```bash
cp .env.example .env
nano .env   # Fill in your values
```

**Required `.env` values:**

```env
DISCORD_TOKEN=your_bot_token
CLIENT_ID=your_application_id
OWNER_ID=your_discord_id
MONGODB_URI=mongodb://localhost:27017/poolstreamer
LAVALINK_HOST=localhost
LAVALINK_PORT=2333
LAVALINK_PASSWORD=youshallnotpass
```

### Step 3 — Start Lavalink (see [Lavalink Setup](#-lavalink-setup))

### Step 4 — Deploy Slash Commands

```bash
node src/deploy-commands.js
```

> ⚠️ You only need to run this once (or when adding new commands). Global deployment takes up to 1 hour to propagate — use guild-specific deploy for instant testing.

### Step 5 — Start the Bot

```bash
# Development (with auto-restart)
npm run dev

# Production
npm start
```

---

## 🎧 Lavalink Setup

Lavalink is the audio backend that handles all streaming. The bot **will not play music** without it.

### Step 1 — Install Java 17

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install -y openjdk-17-jre-headless
java -version  # Should show openjdk 17
```

**Oracle Linux / CentOS:**
```bash
sudo yum install -y java-17-openjdk
```

### Step 2 — Download Lavalink

```bash
mkdir -p ~/lavalink && cd ~/lavalink

# Download latest Lavalink jar
wget https://github.com/lavalink-devs/Lavalink/releases/latest/download/Lavalink.jar

# Copy config
cp /path/to/poolstreamer/lavalink/application.yml .
```

### Step 3 — Edit `application.yml`

Change the password (must match your `.env`):
```yaml
server:
  password: "your_secure_password_here"
```

### Step 4 — Download Plugins (Optional but Recommended)

For **YouTube** support (LavaLink 4.x requires plugin):
```bash
mkdir -p plugins
# Plugin is auto-downloaded on first start if configured in application.yml
```

For **Spotify** support, add credentials to `application.yml`:
```yaml
lavasrc:
  sources:
    spotify:
      clientId: "your_spotify_client_id"
      clientSecret: "your_spotify_client_secret"
```

Get credentials at [developer.spotify.com](https://developer.spotify.com/dashboard).

### Step 5 — Start Lavalink

```bash
cd ~/lavalink
java -jar Lavalink.jar
```

You should see:
```
[main] INFO  lavalink.server.bootstrap.Main - Starting Lavalink
[main] INFO  lavalink.server.bootstrap.Main - Lavalink is ready to accept connections.
```

### Step 6 — Run Lavalink with PM2

```bash
npm install -g pm2

pm2 start "java -jar /root/lavalink/Lavalink.jar" \
  --name lavalink \
  --cwd /root/lavalink \
  --log /root/lavalink/logs/lavalink.log

pm2 save
pm2 startup  # Follow the printed command to enable auto-start
```

---

## 🚀 VPS Deployment — PM2 + NGINX

### Recommended: Oracle Cloud Free Tier (Ampere A1)

Oracle provides **always-free** ARM VMs — perfect for a Discord bot.

---

### Step 1 — Server Initial Setup

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install essentials
sudo apt install -y curl wget git build-essential ufw fail2ban

# Create a non-root user (recommended)
adduser poolstreamer
usermod -aG sudo poolstreamer
su - poolstreamer
```

### Step 2 — Install Node.js v20

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
node --version  # v20.x.x
npm --version
```

### Step 3 — Install Java 17

```bash
sudo apt install -y openjdk-17-jre-headless
java -version
```

### Step 4 — Install MongoDB

```bash
# Import MongoDB GPG key
curl -fsSL https://www.mongodb.org/static/pgp/server-7.0.asc | \
  sudo gpg -o /usr/share/keyrings/mongodb-server-7.0.gpg --dearmor

# Add repo
echo "deb [ arch=amd64,arm64 signed-by=/usr/share/keyrings/mongodb-server-7.0.gpg ] \
  https://repo.mongodb.org/apt/ubuntu jammy/mongodb-org/7.0 multiverse" | \
  sudo tee /etc/apt/sources.list.d/mongodb-org-7.0.list

sudo apt update
sudo apt install -y mongodb-org

# Start & enable MongoDB
sudo systemctl start mongod
sudo systemctl enable mongod
```

### Step 5 — Install PM2

```bash
sudo npm install -g pm2
```

### Step 6 — Clone & Configure Bot

```bash
cd ~
git clone https://github.com/yourname/poolstreamer.git
cd poolstreamer
npm install --production

cp .env.example .env
nano .env  # Fill in all values
```

### Step 7 — Deploy Commands

```bash
node src/deploy-commands.js
```

### Step 8 — Start Lavalink with PM2

```bash
mkdir -p ~/lavalink/logs
cd ~/lavalink
wget https://github.com/lavalink-devs/Lavalink/releases/latest/download/Lavalink.jar
cp ~/poolstreamer/lavalink/application.yml .

pm2 start "java -Xmx256m -jar Lavalink.jar" \
  --name lavalink \
  --cwd ~/lavalink \
  --log ~/lavalink/logs/lavalink.log

# Wait ~10 seconds for Lavalink to start
```

### Step 9 — Start Bot with PM2

```bash
cd ~/poolstreamer
pm2 start ecosystem.config.js
pm2 save
pm2 startup  # Copy and run the printed sudo command
```

### Step 10 — Verify Everything is Running

```bash
pm2 status
# Should show: lavalink (online) | poolstreamer (online)

pm2 logs poolstreamer --lines 50
```

---

### Step 11 — Install NGINX (Reverse Proxy for Health Endpoint)

```bash
sudo apt install -y nginx

sudo nano /etc/nginx/sites-available/poolstreamer
```

Paste this config:
```nginx
server {
    listen 80;
    server_name your-domain.com;   # Or your server IP

    location /health {
        proxy_pass http://127.0.0.1:3000/health;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 10s;
    }

    location / {
        return 404;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/poolstreamer /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### Step 12 — SSL with Certbot (Optional)

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
sudo systemctl reload nginx
```

---

## 🌐 VPS Deployment — Cloudflare Tunnel

Use this if you want to expose your health endpoint **without opening firewall ports**.

### Step 1 — Install cloudflared

```bash
wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb
sudo dpkg -i cloudflared-linux-amd64.deb
cloudflared version
```

### Step 2 — Authenticate with Cloudflare

```bash
cloudflared tunnel login
# Opens browser — select your domain
```

### Step 3 — Create Tunnel

```bash
cloudflared tunnel create poolstreamer-tunnel
# Note the tunnel UUID

mkdir -p ~/.cloudflared
nano ~/.cloudflared/config.yml
```

```yaml
tunnel: YOUR_TUNNEL_UUID_HERE
credentials-file: /home/poolstreamer/.cloudflared/YOUR_TUNNEL_UUID_HERE.json

ingress:
  - hostname: status.your-domain.com
    service: http://localhost:3000
  - service: http_status:404
```

### Step 4 — Route DNS

```bash
cloudflared tunnel route dns poolstreamer-tunnel status.your-domain.com
```

### Step 5 — Run Tunnel with PM2

```bash
pm2 start "cloudflared tunnel run poolstreamer-tunnel" \
  --name cloudflared \
  --log ~/logs/cloudflared.log

pm2 save
```

Health check will be at: `https://status.your-domain.com/health`

---

## 🔒 Security Hardening

### Firewall with UFW

```bash
# Reset and configure
sudo ufw default deny incoming
sudo ufw default allow outgoing

# Allow SSH (change 22 if using custom port)
sudo ufw allow 22/tcp

# Allow NGINX
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Block Lavalink from outside (only allow localhost)
# Lavalink runs on 2333 — do NOT expose this port externally
sudo ufw deny 2333

# Enable firewall
sudo ufw enable
sudo ufw status verbose
```

### Fail2Ban

```bash
sudo systemctl enable fail2ban
sudo systemctl start fail2ban

# Create custom jail for SSH
sudo nano /etc/fail2ban/jail.local
```

```ini
[DEFAULT]
bantime  = 1h
findtime = 10m
maxretry = 5

[sshd]
enabled = true
port    = ssh
logpath = %(sshd_log)s
backend = %(sshd_backend)s
```

```bash
sudo systemctl restart fail2ban
sudo fail2ban-client status
```

### Protect Discord Token

- **Never** commit `.env` to Git
- Use `.gitignore` (already included)
- Rotate token immediately if leaked at [discord.com/developers](https://discord.com/developers/applications)
- Use environment variables — never hardcode

### MongoDB Security

```bash
# Create admin user
mongosh

use admin
db.createUser({
  user: "poolstreamer",
  pwd: "your_strong_password_here",
  roles: [{ role: "readWrite", db: "poolstreamer" }]
})

exit
```

Edit MongoDB config to require auth:
```bash
sudo nano /etc/mongod.conf
```

```yaml
security:
  authorization: enabled
```

Update your `.env`:
```env
MONGODB_URI=mongodb://poolstreamer:your_strong_password_here@localhost:27017/poolstreamer
```

```bash
sudo systemctl restart mongod
```

---

## ⚙️ Environment Variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `DISCORD_TOKEN` | ✅ | — | Bot token from Discord Developer Portal |
| `CLIENT_ID` | ✅ | — | Application ID |
| `OWNER_ID` | ✅ | — | Your Discord user ID |
| `MONGODB_URI` | ✅ | — | MongoDB connection string |
| `LAVALINK_HOST` | ✅ | `localhost` | Lavalink server host |
| `LAVALINK_PORT` | ✅ | `2333` | Lavalink server port |
| `LAVALINK_PASSWORD` | ✅ | — | Lavalink password |
| `LAVALINK_SECURE` | ❌ | `false` | Use WSS for Lavalink |
| `PORT` | ❌ | `3000` | Health check server port |
| `NODE_ENV` | ❌ | `production` | Node environment |
| `LOG_LEVEL` | ❌ | `info` | Log level (error/warn/info/debug) |

---

## 📁 Project Structure

```
poolstreamer/
├── src/
│   ├── commands/
│   │   ├── music/
│   │   │   ├── play.js          # /play command
│   │   │   ├── controls.js      # /skip /pause /resume /stop /leave
│   │   │   ├── queue.js         # /queue /loop /volume /seek /shuffle /nowplaying
│   │   │   └── extras.js        # /247 /autoplay
│   │   └── admin/
│   │       └── moderation.js    # /setdj /whitelist /blacklist
│   ├── events/
│   │   ├── ready.js             # Bot ready event
│   │   ├── interactionCreate.js # Slash commands + buttons
│   │   └── guild.js             # guildCreate / guildDelete
│   ├── handlers/
│   │   ├── commandHandler.js    # Loads all commands into client.commands
│   │   ├── eventHandler.js      # Loads all Discord events
│   │   └── musicEventHandler.js # Loads all Lavalink/Kazagumo events
│   ├── database/
│   │   └── models/
│   │       └── GuildSettings.js # Mongoose model (DJ, whitelist, blacklist, 24/7, etc.)
│   ├── utils/
│   │   ├── logger.js            # Winston logger with daily rotation
│   │   ├── embedBuilder.js      # All embed + button builders
│   │   ├── permissionChecker.js # Admin / DJ / whitelist / blacklist checks
│   │   └── antiSpam.js          # Cooldown + anti-spam logic
│   ├── deploy-commands.js       # Register slash commands with Discord API
│   └── index.js                 # Main entry point
├── lavalink/
│   └── application.yml          # Lavalink server configuration
├── logs/                        # Auto-created at runtime
├── .env.example
├── .gitignore
├── config.json                  # Bot-level settings (colors, emojis, limits)
├── ecosystem.config.js          # PM2 configuration
├── package.json
└── README.md
```

---

## 🔧 Troubleshooting

### Bot not connecting to Lavalink

```
✅ Check Lavalink is running: pm2 status
✅ Check LAVALINK_HOST/PORT/PASSWORD match application.yml
✅ Check Java is v17+: java -version
✅ Look at Lavalink logs: pm2 logs lavalink
```

### Slash commands not showing

```bash
# Re-deploy commands
node src/deploy-commands.js

# If testing, use guild-specific deploy (instant):
# Modify deploy-commands.js to use Routes.applicationGuildCommands(clientId, guildId)
```

### MongoDB connection failed

```bash
sudo systemctl status mongod
sudo journalctl -u mongod --lines 20
# Check MONGODB_URI in .env matches your setup
```

### Bot crashes on startup

```bash
pm2 logs poolstreamer --lines 100
# Usually: missing .env values or MongoDB not running
```

### Music stuttering / lag

```
✅ Ensure VPS has at least 1GB RAM
✅ Set Java heap: java -Xmx256m -jar Lavalink.jar
✅ Check network latency to Lavalink host
✅ Use bufferDurationMs: 400 in application.yml (already set)
```

---

## 📊 Monitoring

```bash
# View all processes
pm2 status

# Live logs
pm2 logs poolstreamer

# CPU/Memory usage
pm2 monit

# Health endpoint
curl http://localhost:3000/health
```

---

## 🔄 Updates

```bash
cd ~/poolstreamer
git pull
npm install --production
node src/deploy-commands.js  # Only if commands changed
pm2 restart poolstreamer
```

---

## 📜 License

MIT © PoolStreamer

---

> Built with ❤️ using discord.js v14, Kazagumo, Shoukaku, and Lavalink.
